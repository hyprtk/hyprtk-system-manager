"""hyprtk-system-manager — a settings application for the whole hyprtk desktop."""

__version__ = "0.6.1"
APP_NAME = "hyprtk-system-manager"
TITLE = "System Settings"
